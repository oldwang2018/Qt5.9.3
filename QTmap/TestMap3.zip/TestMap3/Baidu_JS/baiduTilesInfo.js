var outputPath='../tiles/';
var minLevel=1;
var maxLevel=9;
var centX=122.011032418599;
var centY=31.1061463174144;
var format='.png';
var pointsStr='';
