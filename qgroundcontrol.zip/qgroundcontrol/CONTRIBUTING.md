
Thank you for considering to contribute to QGroundControl.

Contributions must be made under QGroundControl's dual-license system, under GPLv3 and Apache 2.0. This by definition rules out the re-use of any copyleft (e.g. GPL) licensed code. All contributions must be original or from a compatible license (BSD 2/3 clause, MIT, Apache 2.0).

  * https://opensource.org/licenses/gpl-3.0.html
  * https://opensource.org/licenses/Apache-2.0

Users of the codebase are free to use it under either license. The dual approach is necessary to be able to offer QGroundControl through the iOS and Android app stores and offers the open source community choice.
