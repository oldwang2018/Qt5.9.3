This folder contains the various required libraries for QGC to compile. They are distributed with the codebase to ease development.

# Qwt
Qt Widgets for Technical Applications
Version: 6.1
Source obtained: `svn checkout svn://svn.code.sf.net/p/qwt/code/branches/qwt-6.1 qwt`

Contents of `/libs/qwt` is the contents of the `/src` directory from the Qwt repository.
qwt.pri file is custom made to compile all necessary Qwt code in with QGC.
