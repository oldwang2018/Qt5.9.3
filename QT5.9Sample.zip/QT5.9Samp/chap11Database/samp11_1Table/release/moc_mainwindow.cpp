/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[22];
    char stringdata0[451];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 17), // "on_currentChanged"
QT_MOC_LITERAL(2, 29, 0), // ""
QT_MOC_LITERAL(3, 30, 7), // "current"
QT_MOC_LITERAL(4, 38, 8), // "previous"
QT_MOC_LITERAL(5, 47, 20), // "on_currentRowChanged"
QT_MOC_LITERAL(6, 68, 22), // "on_actOpenDB_triggered"
QT_MOC_LITERAL(7, 91, 25), // "on_actRecAppend_triggered"
QT_MOC_LITERAL(8, 117, 25), // "on_actRecInsert_triggered"
QT_MOC_LITERAL(9, 143, 22), // "on_actRevert_triggered"
QT_MOC_LITERAL(10, 166, 22), // "on_actSubmit_triggered"
QT_MOC_LITERAL(11, 189, 25), // "on_actRecDelete_triggered"
QT_MOC_LITERAL(12, 215, 21), // "on_actPhoto_triggered"
QT_MOC_LITERAL(13, 237, 26), // "on_actPhotoClear_triggered"
QT_MOC_LITERAL(14, 264, 25), // "on_radioBtnAscend_clicked"
QT_MOC_LITERAL(15, 290, 26), // "on_radioBtnDescend_clicked"
QT_MOC_LITERAL(16, 317, 22), // "on_radioBtnMan_clicked"
QT_MOC_LITERAL(17, 340, 24), // "on_radioBtnWoman_clicked"
QT_MOC_LITERAL(18, 365, 23), // "on_radioBtnBoth_clicked"
QT_MOC_LITERAL(19, 389, 34), // "on_comboFields_currentIndexCh..."
QT_MOC_LITERAL(20, 424, 5), // "index"
QT_MOC_LITERAL(21, 430, 20) // "on_actScan_triggered"

    },
    "MainWindow\0on_currentChanged\0\0current\0"
    "previous\0on_currentRowChanged\0"
    "on_actOpenDB_triggered\0on_actRecAppend_triggered\0"
    "on_actRecInsert_triggered\0"
    "on_actRevert_triggered\0on_actSubmit_triggered\0"
    "on_actRecDelete_triggered\0"
    "on_actPhoto_triggered\0on_actPhotoClear_triggered\0"
    "on_radioBtnAscend_clicked\0"
    "on_radioBtnDescend_clicked\0"
    "on_radioBtnMan_clicked\0on_radioBtnWoman_clicked\0"
    "on_radioBtnBoth_clicked\0"
    "on_comboFields_currentIndexChanged\0"
    "index\0on_actScan_triggered"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    2,   99,    2, 0x08 /* Private */,
       5,    2,  104,    2, 0x08 /* Private */,
       6,    0,  109,    2, 0x08 /* Private */,
       7,    0,  110,    2, 0x08 /* Private */,
       8,    0,  111,    2, 0x08 /* Private */,
       9,    0,  112,    2, 0x08 /* Private */,
      10,    0,  113,    2, 0x08 /* Private */,
      11,    0,  114,    2, 0x08 /* Private */,
      12,    0,  115,    2, 0x08 /* Private */,
      13,    0,  116,    2, 0x08 /* Private */,
      14,    0,  117,    2, 0x08 /* Private */,
      15,    0,  118,    2, 0x08 /* Private */,
      16,    0,  119,    2, 0x08 /* Private */,
      17,    0,  120,    2, 0x08 /* Private */,
      18,    0,  121,    2, 0x08 /* Private */,
      19,    1,  122,    2, 0x08 /* Private */,
      21,    0,  125,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::QModelIndex, QMetaType::QModelIndex,    3,    4,
    QMetaType::Void, QMetaType::QModelIndex, QMetaType::QModelIndex,    3,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_currentChanged((*reinterpret_cast< const QModelIndex(*)>(_a[1])),(*reinterpret_cast< const QModelIndex(*)>(_a[2]))); break;
        case 1: _t->on_currentRowChanged((*reinterpret_cast< const QModelIndex(*)>(_a[1])),(*reinterpret_cast< const QModelIndex(*)>(_a[2]))); break;
        case 2: _t->on_actOpenDB_triggered(); break;
        case 3: _t->on_actRecAppend_triggered(); break;
        case 4: _t->on_actRecInsert_triggered(); break;
        case 5: _t->on_actRevert_triggered(); break;
        case 6: _t->on_actSubmit_triggered(); break;
        case 7: _t->on_actRecDelete_triggered(); break;
        case 8: _t->on_actPhoto_triggered(); break;
        case 9: _t->on_actPhotoClear_triggered(); break;
        case 10: _t->on_radioBtnAscend_clicked(); break;
        case 11: _t->on_radioBtnDescend_clicked(); break;
        case 12: _t->on_radioBtnMan_clicked(); break;
        case 13: _t->on_radioBtnWoman_clicked(); break;
        case 14: _t->on_radioBtnBoth_clicked(); break;
        case 15: _t->on_comboFields_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->on_actScan_triggered(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 17)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 17;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
