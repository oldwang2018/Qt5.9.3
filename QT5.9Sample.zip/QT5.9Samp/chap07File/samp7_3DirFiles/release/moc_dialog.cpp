/****************************************************************************
** Meta object code from reading C++ file 'dialog.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../dialog.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'dialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Dialog_t {
    QByteArrayData data[66];
    char stringdata0[1562];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Dialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Dialog_t qt_meta_stringdata_Dialog = {
    {
QT_MOC_LITERAL(0, 0, 6), // "Dialog"
QT_MOC_LITERAL(1, 7, 19), // "on_directoryChanged"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 4), // "path"
QT_MOC_LITERAL(4, 33, 14), // "on_fileChanged"
QT_MOC_LITERAL(5, 48, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(6, 70, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(7, 94, 23), // "on_pushButton_3_clicked"
QT_MOC_LITERAL(8, 118, 23), // "on_pushButton_4_clicked"
QT_MOC_LITERAL(9, 142, 23), // "on_pushButton_5_clicked"
QT_MOC_LITERAL(10, 166, 24), // "on_pushButton_41_clicked"
QT_MOC_LITERAL(11, 191, 24), // "on_pushButton_45_clicked"
QT_MOC_LITERAL(12, 216, 24), // "on_pushButton_28_clicked"
QT_MOC_LITERAL(13, 241, 24), // "on_pushButton_29_clicked"
QT_MOC_LITERAL(14, 266, 24), // "on_pushButton_30_clicked"
QT_MOC_LITERAL(15, 291, 24), // "on_pushButton_31_clicked"
QT_MOC_LITERAL(16, 316, 24), // "on_pushButton_32_clicked"
QT_MOC_LITERAL(17, 341, 24), // "on_pushButton_27_clicked"
QT_MOC_LITERAL(18, 366, 24), // "on_pushButton_39_clicked"
QT_MOC_LITERAL(19, 391, 24), // "on_pushButton_33_clicked"
QT_MOC_LITERAL(20, 416, 24), // "on_pushButton_34_clicked"
QT_MOC_LITERAL(21, 441, 24), // "on_pushButton_42_clicked"
QT_MOC_LITERAL(22, 466, 24), // "on_pushButton_43_clicked"
QT_MOC_LITERAL(23, 491, 24), // "on_pushButton_35_clicked"
QT_MOC_LITERAL(24, 516, 24), // "on_pushButton_37_clicked"
QT_MOC_LITERAL(25, 541, 24), // "on_pushButton_36_clicked"
QT_MOC_LITERAL(26, 566, 24), // "on_pushButton_44_clicked"
QT_MOC_LITERAL(27, 591, 24), // "on_pushButton_38_clicked"
QT_MOC_LITERAL(28, 616, 24), // "on_pushButton_10_clicked"
QT_MOC_LITERAL(29, 641, 23), // "on_pushButton_9_clicked"
QT_MOC_LITERAL(30, 665, 23), // "on_pushButton_8_clicked"
QT_MOC_LITERAL(31, 689, 23), // "on_pushButton_6_clicked"
QT_MOC_LITERAL(32, 713, 23), // "on_pushButton_7_clicked"
QT_MOC_LITERAL(33, 737, 24), // "on_pushButton_13_clicked"
QT_MOC_LITERAL(34, 762, 24), // "on_pushButton_14_clicked"
QT_MOC_LITERAL(35, 787, 24), // "on_pushButton_15_clicked"
QT_MOC_LITERAL(36, 812, 24), // "on_pushButton_19_clicked"
QT_MOC_LITERAL(37, 837, 24), // "on_pushButton_16_clicked"
QT_MOC_LITERAL(38, 862, 24), // "on_pushButton_18_clicked"
QT_MOC_LITERAL(39, 887, 24), // "on_pushButton_17_clicked"
QT_MOC_LITERAL(40, 912, 24), // "on_pushButton_11_clicked"
QT_MOC_LITERAL(41, 937, 24), // "on_pushButton_24_clicked"
QT_MOC_LITERAL(42, 962, 24), // "on_pushButton_20_clicked"
QT_MOC_LITERAL(43, 987, 24), // "on_pushButton_26_clicked"
QT_MOC_LITERAL(44, 1012, 24), // "on_pushButton_22_clicked"
QT_MOC_LITERAL(45, 1037, 24), // "on_pushButton_12_clicked"
QT_MOC_LITERAL(46, 1062, 24), // "on_pushButton_23_clicked"
QT_MOC_LITERAL(47, 1087, 24), // "on_pushButton_21_clicked"
QT_MOC_LITERAL(48, 1112, 24), // "on_pushButton_25_clicked"
QT_MOC_LITERAL(49, 1137, 24), // "on_pushButton_40_clicked"
QT_MOC_LITERAL(50, 1162, 24), // "on_pushButton_48_clicked"
QT_MOC_LITERAL(51, 1187, 24), // "on_pushButton_51_clicked"
QT_MOC_LITERAL(52, 1212, 24), // "on_pushButton_54_clicked"
QT_MOC_LITERAL(53, 1237, 24), // "on_pushButton_53_clicked"
QT_MOC_LITERAL(54, 1262, 24), // "on_pushButton_49_clicked"
QT_MOC_LITERAL(55, 1287, 24), // "on_pushButton_50_clicked"
QT_MOC_LITERAL(56, 1312, 24), // "on_pushButton_55_clicked"
QT_MOC_LITERAL(57, 1337, 24), // "on_pushButton_56_clicked"
QT_MOC_LITERAL(58, 1362, 24), // "on_pushButton_46_clicked"
QT_MOC_LITERAL(59, 1387, 24), // "on_pushButton_47_clicked"
QT_MOC_LITERAL(60, 1412, 24), // "on_pushButton_52_clicked"
QT_MOC_LITERAL(61, 1437, 24), // "on_pushButton_57_clicked"
QT_MOC_LITERAL(62, 1462, 24), // "on_pushButton_59_clicked"
QT_MOC_LITERAL(63, 1487, 24), // "on_pushButton_58_clicked"
QT_MOC_LITERAL(64, 1512, 24), // "on_pushButton_60_clicked"
QT_MOC_LITERAL(65, 1537, 24) // "on_pushButton_61_clicked"

    },
    "Dialog\0on_directoryChanged\0\0path\0"
    "on_fileChanged\0on_pushButton_clicked\0"
    "on_pushButton_2_clicked\0on_pushButton_3_clicked\0"
    "on_pushButton_4_clicked\0on_pushButton_5_clicked\0"
    "on_pushButton_41_clicked\0"
    "on_pushButton_45_clicked\0"
    "on_pushButton_28_clicked\0"
    "on_pushButton_29_clicked\0"
    "on_pushButton_30_clicked\0"
    "on_pushButton_31_clicked\0"
    "on_pushButton_32_clicked\0"
    "on_pushButton_27_clicked\0"
    "on_pushButton_39_clicked\0"
    "on_pushButton_33_clicked\0"
    "on_pushButton_34_clicked\0"
    "on_pushButton_42_clicked\0"
    "on_pushButton_43_clicked\0"
    "on_pushButton_35_clicked\0"
    "on_pushButton_37_clicked\0"
    "on_pushButton_36_clicked\0"
    "on_pushButton_44_clicked\0"
    "on_pushButton_38_clicked\0"
    "on_pushButton_10_clicked\0"
    "on_pushButton_9_clicked\0on_pushButton_8_clicked\0"
    "on_pushButton_6_clicked\0on_pushButton_7_clicked\0"
    "on_pushButton_13_clicked\0"
    "on_pushButton_14_clicked\0"
    "on_pushButton_15_clicked\0"
    "on_pushButton_19_clicked\0"
    "on_pushButton_16_clicked\0"
    "on_pushButton_18_clicked\0"
    "on_pushButton_17_clicked\0"
    "on_pushButton_11_clicked\0"
    "on_pushButton_24_clicked\0"
    "on_pushButton_20_clicked\0"
    "on_pushButton_26_clicked\0"
    "on_pushButton_22_clicked\0"
    "on_pushButton_12_clicked\0"
    "on_pushButton_23_clicked\0"
    "on_pushButton_21_clicked\0"
    "on_pushButton_25_clicked\0"
    "on_pushButton_40_clicked\0"
    "on_pushButton_48_clicked\0"
    "on_pushButton_51_clicked\0"
    "on_pushButton_54_clicked\0"
    "on_pushButton_53_clicked\0"
    "on_pushButton_49_clicked\0"
    "on_pushButton_50_clicked\0"
    "on_pushButton_55_clicked\0"
    "on_pushButton_56_clicked\0"
    "on_pushButton_46_clicked\0"
    "on_pushButton_47_clicked\0"
    "on_pushButton_52_clicked\0"
    "on_pushButton_57_clicked\0"
    "on_pushButton_59_clicked\0"
    "on_pushButton_58_clicked\0"
    "on_pushButton_60_clicked\0"
    "on_pushButton_61_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Dialog[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      63,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  329,    2, 0x0a /* Public */,
       4,    1,  332,    2, 0x0a /* Public */,
       5,    0,  335,    2, 0x08 /* Private */,
       6,    0,  336,    2, 0x08 /* Private */,
       7,    0,  337,    2, 0x08 /* Private */,
       8,    0,  338,    2, 0x08 /* Private */,
       9,    0,  339,    2, 0x08 /* Private */,
      10,    0,  340,    2, 0x08 /* Private */,
      11,    0,  341,    2, 0x08 /* Private */,
      12,    0,  342,    2, 0x08 /* Private */,
      13,    0,  343,    2, 0x08 /* Private */,
      14,    0,  344,    2, 0x08 /* Private */,
      15,    0,  345,    2, 0x08 /* Private */,
      16,    0,  346,    2, 0x08 /* Private */,
      17,    0,  347,    2, 0x08 /* Private */,
      18,    0,  348,    2, 0x08 /* Private */,
      19,    0,  349,    2, 0x08 /* Private */,
      20,    0,  350,    2, 0x08 /* Private */,
      21,    0,  351,    2, 0x08 /* Private */,
      22,    0,  352,    2, 0x08 /* Private */,
      23,    0,  353,    2, 0x08 /* Private */,
      24,    0,  354,    2, 0x08 /* Private */,
      25,    0,  355,    2, 0x08 /* Private */,
      26,    0,  356,    2, 0x08 /* Private */,
      27,    0,  357,    2, 0x08 /* Private */,
      28,    0,  358,    2, 0x08 /* Private */,
      29,    0,  359,    2, 0x08 /* Private */,
      30,    0,  360,    2, 0x08 /* Private */,
      31,    0,  361,    2, 0x08 /* Private */,
      32,    0,  362,    2, 0x08 /* Private */,
      33,    0,  363,    2, 0x08 /* Private */,
      34,    0,  364,    2, 0x08 /* Private */,
      35,    0,  365,    2, 0x08 /* Private */,
      36,    0,  366,    2, 0x08 /* Private */,
      37,    0,  367,    2, 0x08 /* Private */,
      38,    0,  368,    2, 0x08 /* Private */,
      39,    0,  369,    2, 0x08 /* Private */,
      40,    0,  370,    2, 0x08 /* Private */,
      41,    0,  371,    2, 0x08 /* Private */,
      42,    0,  372,    2, 0x08 /* Private */,
      43,    0,  373,    2, 0x08 /* Private */,
      44,    0,  374,    2, 0x08 /* Private */,
      45,    0,  375,    2, 0x08 /* Private */,
      46,    0,  376,    2, 0x08 /* Private */,
      47,    0,  377,    2, 0x08 /* Private */,
      48,    0,  378,    2, 0x08 /* Private */,
      49,    0,  379,    2, 0x08 /* Private */,
      50,    0,  380,    2, 0x08 /* Private */,
      51,    0,  381,    2, 0x08 /* Private */,
      52,    0,  382,    2, 0x08 /* Private */,
      53,    0,  383,    2, 0x08 /* Private */,
      54,    0,  384,    2, 0x08 /* Private */,
      55,    0,  385,    2, 0x08 /* Private */,
      56,    0,  386,    2, 0x08 /* Private */,
      57,    0,  387,    2, 0x08 /* Private */,
      58,    0,  388,    2, 0x08 /* Private */,
      59,    0,  389,    2, 0x08 /* Private */,
      60,    0,  390,    2, 0x08 /* Private */,
      61,    0,  391,    2, 0x08 /* Private */,
      62,    0,  392,    2, 0x08 /* Private */,
      63,    0,  393,    2, 0x08 /* Private */,
      64,    0,  394,    2, 0x08 /* Private */,
      65,    0,  395,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Dialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Dialog *_t = static_cast<Dialog *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_directoryChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: _t->on_fileChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->on_pushButton_clicked(); break;
        case 3: _t->on_pushButton_2_clicked(); break;
        case 4: _t->on_pushButton_3_clicked(); break;
        case 5: _t->on_pushButton_4_clicked(); break;
        case 6: _t->on_pushButton_5_clicked(); break;
        case 7: _t->on_pushButton_41_clicked(); break;
        case 8: _t->on_pushButton_45_clicked(); break;
        case 9: _t->on_pushButton_28_clicked(); break;
        case 10: _t->on_pushButton_29_clicked(); break;
        case 11: _t->on_pushButton_30_clicked(); break;
        case 12: _t->on_pushButton_31_clicked(); break;
        case 13: _t->on_pushButton_32_clicked(); break;
        case 14: _t->on_pushButton_27_clicked(); break;
        case 15: _t->on_pushButton_39_clicked(); break;
        case 16: _t->on_pushButton_33_clicked(); break;
        case 17: _t->on_pushButton_34_clicked(); break;
        case 18: _t->on_pushButton_42_clicked(); break;
        case 19: _t->on_pushButton_43_clicked(); break;
        case 20: _t->on_pushButton_35_clicked(); break;
        case 21: _t->on_pushButton_37_clicked(); break;
        case 22: _t->on_pushButton_36_clicked(); break;
        case 23: _t->on_pushButton_44_clicked(); break;
        case 24: _t->on_pushButton_38_clicked(); break;
        case 25: _t->on_pushButton_10_clicked(); break;
        case 26: _t->on_pushButton_9_clicked(); break;
        case 27: _t->on_pushButton_8_clicked(); break;
        case 28: _t->on_pushButton_6_clicked(); break;
        case 29: _t->on_pushButton_7_clicked(); break;
        case 30: _t->on_pushButton_13_clicked(); break;
        case 31: _t->on_pushButton_14_clicked(); break;
        case 32: _t->on_pushButton_15_clicked(); break;
        case 33: _t->on_pushButton_19_clicked(); break;
        case 34: _t->on_pushButton_16_clicked(); break;
        case 35: _t->on_pushButton_18_clicked(); break;
        case 36: _t->on_pushButton_17_clicked(); break;
        case 37: _t->on_pushButton_11_clicked(); break;
        case 38: _t->on_pushButton_24_clicked(); break;
        case 39: _t->on_pushButton_20_clicked(); break;
        case 40: _t->on_pushButton_26_clicked(); break;
        case 41: _t->on_pushButton_22_clicked(); break;
        case 42: _t->on_pushButton_12_clicked(); break;
        case 43: _t->on_pushButton_23_clicked(); break;
        case 44: _t->on_pushButton_21_clicked(); break;
        case 45: _t->on_pushButton_25_clicked(); break;
        case 46: _t->on_pushButton_40_clicked(); break;
        case 47: _t->on_pushButton_48_clicked(); break;
        case 48: _t->on_pushButton_51_clicked(); break;
        case 49: _t->on_pushButton_54_clicked(); break;
        case 50: _t->on_pushButton_53_clicked(); break;
        case 51: _t->on_pushButton_49_clicked(); break;
        case 52: _t->on_pushButton_50_clicked(); break;
        case 53: _t->on_pushButton_55_clicked(); break;
        case 54: _t->on_pushButton_56_clicked(); break;
        case 55: _t->on_pushButton_46_clicked(); break;
        case 56: _t->on_pushButton_47_clicked(); break;
        case 57: _t->on_pushButton_52_clicked(); break;
        case 58: _t->on_pushButton_57_clicked(); break;
        case 59: _t->on_pushButton_59_clicked(); break;
        case 60: _t->on_pushButton_58_clicked(); break;
        case 61: _t->on_pushButton_60_clicked(); break;
        case 62: _t->on_pushButton_61_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject Dialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_Dialog.data,
      qt_meta_data_Dialog,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *Dialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Dialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Dialog.stringdata0))
        return static_cast<void*>(const_cast< Dialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int Dialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 63)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 63;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 63)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 63;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
