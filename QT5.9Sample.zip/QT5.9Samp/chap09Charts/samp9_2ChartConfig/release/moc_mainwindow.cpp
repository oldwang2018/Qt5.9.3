/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[60];
    char stringdata0[1500];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 22), // "on_LegendMarkerClicked"
QT_MOC_LITERAL(2, 34, 0), // ""
QT_MOC_LITERAL(3, 35, 20), // "on_actDraw_triggered"
QT_MOC_LITERAL(4, 56, 22), // "on_btnSetTitle_clicked"
QT_MOC_LITERAL(5, 79, 26), // "on_btnSetTitleFont_clicked"
QT_MOC_LITERAL(6, 106, 23), // "on_btnSetMargin_clicked"
QT_MOC_LITERAL(7, 130, 26), // "on_chkPointVisible_clicked"
QT_MOC_LITERAL(8, 157, 7), // "checked"
QT_MOC_LITERAL(9, 165, 31), // "on_chkPointLabelVisible_clicked"
QT_MOC_LITERAL(10, 197, 24), // "on_btnSeriesName_clicked"
QT_MOC_LITERAL(11, 222, 25), // "on_btnSeriesColor_clicked"
QT_MOC_LITERAL(12, 248, 27), // "on_chkLegendVisible_clicked"
QT_MOC_LITERAL(13, 276, 26), // "on_btnSetAxisRange_clicked"
QT_MOC_LITERAL(14, 303, 29), // "on_spinTickCount_valueChanged"
QT_MOC_LITERAL(15, 333, 4), // "arg1"
QT_MOC_LITERAL(16, 338, 34), // "on_spinMinorTickCount_valueCh..."
QT_MOC_LITERAL(17, 373, 17), // "on_radioX_clicked"
QT_MOC_LITERAL(18, 391, 17), // "on_radioY_clicked"
QT_MOC_LITERAL(19, 409, 19), // "on_checkBox_clicked"
QT_MOC_LITERAL(20, 429, 29), // "on_chkGridLineVisible_clicked"
QT_MOC_LITERAL(21, 459, 30), // "on_chkMinorTickVisible_clicked"
QT_MOC_LITERAL(22, 490, 33), // "on_chkBoxLegendBackground_cli..."
QT_MOC_LITERAL(23, 524, 22), // "on_radioButton_clicked"
QT_MOC_LITERAL(24, 547, 24), // "on_radioButton_2_clicked"
QT_MOC_LITERAL(25, 572, 24), // "on_radioButton_3_clicked"
QT_MOC_LITERAL(26, 597, 24), // "on_radioButton_4_clicked"
QT_MOC_LITERAL(27, 622, 24), // "on_btnLegendFont_clicked"
QT_MOC_LITERAL(28, 647, 30), // "on_btnLegendlabelColor_clicked"
QT_MOC_LITERAL(29, 678, 24), // "on_chkBoxVisible_clicked"
QT_MOC_LITERAL(30, 703, 26), // "on_btnAxisSetTitle_clicked"
QT_MOC_LITERAL(31, 730, 30), // "on_btnAxisSetTitleFont_clicked"
QT_MOC_LITERAL(32, 761, 26), // "on_chkBoxAxisTitle_clicked"
QT_MOC_LITERAL(33, 788, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(34, 810, 28), // "on_btnAxisLabelColor_clicked"
QT_MOC_LITERAL(35, 839, 27), // "on_btnAxisLabelFont_clicked"
QT_MOC_LITERAL(36, 867, 30), // "on_chkBoxLabelsVisible_clicked"
QT_MOC_LITERAL(37, 898, 27), // "on_btnGridLineColor_clicked"
QT_MOC_LITERAL(38, 926, 24), // "on_pushButton_10_clicked"
QT_MOC_LITERAL(39, 951, 29), // "on_chkAxisLineVisible_clicked"
QT_MOC_LITERAL(40, 981, 25), // "on_btnAxisLinePen_clicked"
QT_MOC_LITERAL(41, 1007, 30), // "on_btnAxisLinePenColor_clicked"
QT_MOC_LITERAL(42, 1038, 24), // "on_btnMinorColor_clicked"
QT_MOC_LITERAL(43, 1063, 22), // "on_btnMinorPen_clicked"
QT_MOC_LITERAL(44, 1086, 23), // "on_radioSeries0_clicked"
QT_MOC_LITERAL(45, 1110, 23), // "on_radioSeries1_clicked"
QT_MOC_LITERAL(46, 1134, 27), // "on_chkSeriesVisible_clicked"
QT_MOC_LITERAL(47, 1162, 23), // "on_btnSeriesPen_clicked"
QT_MOC_LITERAL(48, 1186, 35), // "on_sliderSeriesOpacity_valueC..."
QT_MOC_LITERAL(49, 1222, 5), // "value"
QT_MOC_LITERAL(50, 1228, 28), // "on_btnSeriesLabColor_clicked"
QT_MOC_LITERAL(51, 1257, 27), // "on_btnSeriesLabFont_clicked"
QT_MOC_LITERAL(52, 1285, 32), // "on_radioSeriesLabFormat0_clicked"
QT_MOC_LITERAL(53, 1318, 32), // "on_radioSeriesLabFormat1_clicked"
QT_MOC_LITERAL(54, 1351, 36), // "on_cBoxAnimation_currentIndex..."
QT_MOC_LITERAL(55, 1388, 5), // "index"
QT_MOC_LITERAL(56, 1394, 32), // "on_cBoxTheme_currentIndexChanged"
QT_MOC_LITERAL(57, 1427, 22), // "on_actZoomIn_triggered"
QT_MOC_LITERAL(58, 1450, 23), // "on_actZoomOut_triggered"
QT_MOC_LITERAL(59, 1474, 25) // "on_actZoomReset_triggered"

    },
    "MainWindow\0on_LegendMarkerClicked\0\0"
    "on_actDraw_triggered\0on_btnSetTitle_clicked\0"
    "on_btnSetTitleFont_clicked\0"
    "on_btnSetMargin_clicked\0"
    "on_chkPointVisible_clicked\0checked\0"
    "on_chkPointLabelVisible_clicked\0"
    "on_btnSeriesName_clicked\0"
    "on_btnSeriesColor_clicked\0"
    "on_chkLegendVisible_clicked\0"
    "on_btnSetAxisRange_clicked\0"
    "on_spinTickCount_valueChanged\0arg1\0"
    "on_spinMinorTickCount_valueChanged\0"
    "on_radioX_clicked\0on_radioY_clicked\0"
    "on_checkBox_clicked\0on_chkGridLineVisible_clicked\0"
    "on_chkMinorTickVisible_clicked\0"
    "on_chkBoxLegendBackground_clicked\0"
    "on_radioButton_clicked\0on_radioButton_2_clicked\0"
    "on_radioButton_3_clicked\0"
    "on_radioButton_4_clicked\0"
    "on_btnLegendFont_clicked\0"
    "on_btnLegendlabelColor_clicked\0"
    "on_chkBoxVisible_clicked\0"
    "on_btnAxisSetTitle_clicked\0"
    "on_btnAxisSetTitleFont_clicked\0"
    "on_chkBoxAxisTitle_clicked\0"
    "on_pushButton_clicked\0"
    "on_btnAxisLabelColor_clicked\0"
    "on_btnAxisLabelFont_clicked\0"
    "on_chkBoxLabelsVisible_clicked\0"
    "on_btnGridLineColor_clicked\0"
    "on_pushButton_10_clicked\0"
    "on_chkAxisLineVisible_clicked\0"
    "on_btnAxisLinePen_clicked\0"
    "on_btnAxisLinePenColor_clicked\0"
    "on_btnMinorColor_clicked\0"
    "on_btnMinorPen_clicked\0on_radioSeries0_clicked\0"
    "on_radioSeries1_clicked\0"
    "on_chkSeriesVisible_clicked\0"
    "on_btnSeriesPen_clicked\0"
    "on_sliderSeriesOpacity_valueChanged\0"
    "value\0on_btnSeriesLabColor_clicked\0"
    "on_btnSeriesLabFont_clicked\0"
    "on_radioSeriesLabFormat0_clicked\0"
    "on_radioSeriesLabFormat1_clicked\0"
    "on_cBoxAnimation_currentIndexChanged\0"
    "index\0on_cBoxTheme_currentIndexChanged\0"
    "on_actZoomIn_triggered\0on_actZoomOut_triggered\0"
    "on_actZoomReset_triggered"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      54,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  284,    2, 0x08 /* Private */,
       3,    0,  285,    2, 0x08 /* Private */,
       4,    0,  286,    2, 0x08 /* Private */,
       5,    0,  287,    2, 0x08 /* Private */,
       6,    0,  288,    2, 0x08 /* Private */,
       7,    1,  289,    2, 0x08 /* Private */,
       9,    1,  292,    2, 0x08 /* Private */,
      10,    0,  295,    2, 0x08 /* Private */,
      11,    0,  296,    2, 0x08 /* Private */,
      12,    1,  297,    2, 0x08 /* Private */,
      13,    0,  300,    2, 0x08 /* Private */,
      14,    1,  301,    2, 0x08 /* Private */,
      16,    1,  304,    2, 0x08 /* Private */,
      17,    0,  307,    2, 0x08 /* Private */,
      18,    0,  308,    2, 0x08 /* Private */,
      19,    1,  309,    2, 0x08 /* Private */,
      20,    1,  312,    2, 0x08 /* Private */,
      21,    1,  315,    2, 0x08 /* Private */,
      22,    1,  318,    2, 0x08 /* Private */,
      23,    0,  321,    2, 0x08 /* Private */,
      24,    0,  322,    2, 0x08 /* Private */,
      25,    0,  323,    2, 0x08 /* Private */,
      26,    0,  324,    2, 0x08 /* Private */,
      27,    0,  325,    2, 0x08 /* Private */,
      28,    0,  326,    2, 0x08 /* Private */,
      29,    1,  327,    2, 0x08 /* Private */,
      30,    0,  330,    2, 0x08 /* Private */,
      31,    0,  331,    2, 0x08 /* Private */,
      32,    1,  332,    2, 0x08 /* Private */,
      33,    0,  335,    2, 0x08 /* Private */,
      34,    0,  336,    2, 0x08 /* Private */,
      35,    0,  337,    2, 0x08 /* Private */,
      36,    1,  338,    2, 0x08 /* Private */,
      37,    0,  341,    2, 0x08 /* Private */,
      38,    0,  342,    2, 0x08 /* Private */,
      39,    1,  343,    2, 0x08 /* Private */,
      40,    0,  346,    2, 0x08 /* Private */,
      41,    0,  347,    2, 0x08 /* Private */,
      42,    0,  348,    2, 0x08 /* Private */,
      43,    0,  349,    2, 0x08 /* Private */,
      44,    0,  350,    2, 0x08 /* Private */,
      45,    0,  351,    2, 0x08 /* Private */,
      46,    1,  352,    2, 0x08 /* Private */,
      47,    0,  355,    2, 0x08 /* Private */,
      48,    1,  356,    2, 0x08 /* Private */,
      50,    0,  359,    2, 0x08 /* Private */,
      51,    0,  360,    2, 0x08 /* Private */,
      52,    0,  361,    2, 0x08 /* Private */,
      53,    0,  362,    2, 0x08 /* Private */,
      54,    1,  363,    2, 0x08 /* Private */,
      56,    1,  366,    2, 0x08 /* Private */,
      57,    0,  369,    2, 0x08 /* Private */,
      58,    0,  370,    2, 0x08 /* Private */,
      59,    0,  371,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   49,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   55,
    QMetaType::Void, QMetaType::Int,   55,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_LegendMarkerClicked(); break;
        case 1: _t->on_actDraw_triggered(); break;
        case 2: _t->on_btnSetTitle_clicked(); break;
        case 3: _t->on_btnSetTitleFont_clicked(); break;
        case 4: _t->on_btnSetMargin_clicked(); break;
        case 5: _t->on_chkPointVisible_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: _t->on_chkPointLabelVisible_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->on_btnSeriesName_clicked(); break;
        case 8: _t->on_btnSeriesColor_clicked(); break;
        case 9: _t->on_chkLegendVisible_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->on_btnSetAxisRange_clicked(); break;
        case 11: _t->on_spinTickCount_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->on_spinMinorTickCount_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->on_radioX_clicked(); break;
        case 14: _t->on_radioY_clicked(); break;
        case 15: _t->on_checkBox_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 16: _t->on_chkGridLineVisible_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 17: _t->on_chkMinorTickVisible_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 18: _t->on_chkBoxLegendBackground_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 19: _t->on_radioButton_clicked(); break;
        case 20: _t->on_radioButton_2_clicked(); break;
        case 21: _t->on_radioButton_3_clicked(); break;
        case 22: _t->on_radioButton_4_clicked(); break;
        case 23: _t->on_btnLegendFont_clicked(); break;
        case 24: _t->on_btnLegendlabelColor_clicked(); break;
        case 25: _t->on_chkBoxVisible_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 26: _t->on_btnAxisSetTitle_clicked(); break;
        case 27: _t->on_btnAxisSetTitleFont_clicked(); break;
        case 28: _t->on_chkBoxAxisTitle_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 29: _t->on_pushButton_clicked(); break;
        case 30: _t->on_btnAxisLabelColor_clicked(); break;
        case 31: _t->on_btnAxisLabelFont_clicked(); break;
        case 32: _t->on_chkBoxLabelsVisible_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 33: _t->on_btnGridLineColor_clicked(); break;
        case 34: _t->on_pushButton_10_clicked(); break;
        case 35: _t->on_chkAxisLineVisible_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 36: _t->on_btnAxisLinePen_clicked(); break;
        case 37: _t->on_btnAxisLinePenColor_clicked(); break;
        case 38: _t->on_btnMinorColor_clicked(); break;
        case 39: _t->on_btnMinorPen_clicked(); break;
        case 40: _t->on_radioSeries0_clicked(); break;
        case 41: _t->on_radioSeries1_clicked(); break;
        case 42: _t->on_chkSeriesVisible_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 43: _t->on_btnSeriesPen_clicked(); break;
        case 44: _t->on_sliderSeriesOpacity_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 45: _t->on_btnSeriesLabColor_clicked(); break;
        case 46: _t->on_btnSeriesLabFont_clicked(); break;
        case 47: _t->on_radioSeriesLabFormat0_clicked(); break;
        case 48: _t->on_radioSeriesLabFormat1_clicked(); break;
        case 49: _t->on_cBoxAnimation_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 50: _t->on_cBoxTheme_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 51: _t->on_actZoomIn_triggered(); break;
        case 52: _t->on_actZoomOut_triggered(); break;
        case 53: _t->on_actZoomReset_triggered(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 54)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 54;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 54)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 54;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
