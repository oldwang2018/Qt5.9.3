/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[27];
    char stringdata0[620];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 21), // "on_chkBoxGrid_clicked"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 7), // "checked"
QT_MOC_LITERAL(4, 42, 23), // "on_chkBoxSmooth_clicked"
QT_MOC_LITERAL(5, 66, 27), // "on_chkBoxReflection_clicked"
QT_MOC_LITERAL(6, 94, 26), // "on_chkBoxAxisTitle_clicked"
QT_MOC_LITERAL(7, 121, 31), // "on_chkBoxAxisBackground_clicked"
QT_MOC_LITERAL(8, 153, 24), // "on_chkBoxReverse_clicked"
QT_MOC_LITERAL(9, 178, 27), // "on_chkBoxBackground_clicked"
QT_MOC_LITERAL(10, 206, 28), // "on_spinFontSize_valueChanged"
QT_MOC_LITERAL(11, 235, 4), // "arg1"
QT_MOC_LITERAL(12, 240, 32), // "on_cBoxTheme_currentIndexChanged"
QT_MOC_LITERAL(13, 273, 5), // "index"
QT_MOC_LITERAL(14, 279, 22), // "on_btnBarColor_clicked"
QT_MOC_LITERAL(15, 302, 26), // "on_chkBoxItemLabel_clicked"
QT_MOC_LITERAL(16, 329, 35), // "on_cBoxBarStyle_currentIndexC..."
QT_MOC_LITERAL(17, 365, 40), // "on_cBoxSelectionMode_currentI..."
QT_MOC_LITERAL(18, 406, 23), // "on_chkBoxShadow_clicked"
QT_MOC_LITERAL(19, 430, 31), // "on_comboBox_currentIndexChanged"
QT_MOC_LITERAL(20, 462, 23), // "on_sliderH_valueChanged"
QT_MOC_LITERAL(21, 486, 5), // "value"
QT_MOC_LITERAL(22, 492, 23), // "on_sliderV_valueChanged"
QT_MOC_LITERAL(23, 516, 36), // "on_comboDrawMode_currentIndex..."
QT_MOC_LITERAL(24, 553, 19), // "on_btnGrad1_clicked"
QT_MOC_LITERAL(25, 573, 19), // "on_btnGrad2_clicked"
QT_MOC_LITERAL(26, 593, 26) // "on_sliderZoom_valueChanged"

    },
    "MainWindow\0on_chkBoxGrid_clicked\0\0"
    "checked\0on_chkBoxSmooth_clicked\0"
    "on_chkBoxReflection_clicked\0"
    "on_chkBoxAxisTitle_clicked\0"
    "on_chkBoxAxisBackground_clicked\0"
    "on_chkBoxReverse_clicked\0"
    "on_chkBoxBackground_clicked\0"
    "on_spinFontSize_valueChanged\0arg1\0"
    "on_cBoxTheme_currentIndexChanged\0index\0"
    "on_btnBarColor_clicked\0"
    "on_chkBoxItemLabel_clicked\0"
    "on_cBoxBarStyle_currentIndexChanged\0"
    "on_cBoxSelectionMode_currentIndexChanged\0"
    "on_chkBoxShadow_clicked\0"
    "on_comboBox_currentIndexChanged\0"
    "on_sliderH_valueChanged\0value\0"
    "on_sliderV_valueChanged\0"
    "on_comboDrawMode_currentIndexChanged\0"
    "on_btnGrad1_clicked\0on_btnGrad2_clicked\0"
    "on_sliderZoom_valueChanged"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  119,    2, 0x08 /* Private */,
       4,    1,  122,    2, 0x08 /* Private */,
       5,    1,  125,    2, 0x08 /* Private */,
       6,    1,  128,    2, 0x08 /* Private */,
       7,    1,  131,    2, 0x08 /* Private */,
       8,    1,  134,    2, 0x08 /* Private */,
       9,    1,  137,    2, 0x08 /* Private */,
      10,    1,  140,    2, 0x08 /* Private */,
      12,    1,  143,    2, 0x08 /* Private */,
      14,    0,  146,    2, 0x08 /* Private */,
      15,    1,  147,    2, 0x08 /* Private */,
      16,    1,  150,    2, 0x08 /* Private */,
      17,    1,  153,    2, 0x08 /* Private */,
      18,    1,  156,    2, 0x08 /* Private */,
      19,    1,  159,    2, 0x08 /* Private */,
      20,    1,  162,    2, 0x08 /* Private */,
      22,    1,  165,    2, 0x08 /* Private */,
      23,    1,  168,    2, 0x08 /* Private */,
      24,    0,  171,    2, 0x08 /* Private */,
      25,    0,  172,    2, 0x08 /* Private */,
      26,    1,  173,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Int,   11,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   21,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_chkBoxGrid_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->on_chkBoxSmooth_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->on_chkBoxReflection_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->on_chkBoxAxisTitle_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->on_chkBoxAxisBackground_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->on_chkBoxReverse_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: _t->on_chkBoxBackground_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->on_spinFontSize_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->on_cBoxTheme_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->on_btnBarColor_clicked(); break;
        case 10: _t->on_chkBoxItemLabel_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 11: _t->on_cBoxBarStyle_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->on_cBoxSelectionMode_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->on_chkBoxShadow_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 14: _t->on_comboBox_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->on_sliderH_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->on_sliderV_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->on_comboDrawMode_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->on_btnGrad1_clicked(); break;
        case 19: _t->on_btnGrad2_clicked(); break;
        case 20: _t->on_sliderZoom_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 21;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
